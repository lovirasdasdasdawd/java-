package dev.donuttracker.fabric;
import net.minecraft.class_332;
/** Scanline circles/capsules; no shaders or texture-loader dependencies. */
public final class OrbitShapes {
 public static void pill(class_332 g,int x,int y,int w,int h,int color){
  if(w<1||h<1)return;double r=Math.min(w,h)/2.0;
  for(int yy=0;yy<h;yy++){double d=Math.max(0,r-Math.min(yy+.5,h-yy-.5));int inset=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-d*d)));if(w>inset*2)g.method_25294(x+inset,y+yy,x+w-inset,y+yy+1,color);}
 }
 public static void disc(class_332 g,int x,int y,int radius,int color){pill(g,x-radius,y-radius,radius*2,radius*2,color);}
 public static void ring(class_332 g,int x,int y,int radius,int thick,int color){
  int inner=Math.max(0,radius-thick);
  for(int yy=-radius;yy<radius;yy++){double dy=yy+.5;int outside=(int)Math.floor(Math.sqrt(Math.max(0,radius*radius-dy*dy)));int inside=Math.abs(dy)<inner?(int)Math.floor(Math.sqrt(Math.max(0,inner*inner-dy*dy))):0;
   if(outside<=0)continue;if(inside==0)g.method_25294(x-outside,y+yy,x+outside,y+yy+1,color);else{g.method_25294(x-outside,y+yy,x-inside,y+yy+1,color);g.method_25294(x+inside,y+yy,x+outside,y+yy+1,color);}}
 }
 public static void arc(class_332 g,int x,int y,int radius,double start,double length,int color){
  int steps=Math.max(1,(int)Math.ceil(Math.abs(length)*Math.max(1,radius)/1.1));
  for(int i=0;i<=steps;i++){double a=start+length*i/steps;int xx=(int)Math.round(x+Math.cos(a)*radius),yy=(int)Math.round(y+Math.sin(a)*radius);g.method_25294(xx-1,yy-1,xx+1,yy+1,color);}
 }
 public static void dash(class_332 g,int x1,int y1,int x2,int y2,int color){int n=Math.max(Math.abs(x2-x1),Math.abs(y2-y1));for(int i=0;i<=n;i+=3){int x=x1+(x2-x1)*i/Math.max(1,n),y=y1+(y2-y1)*i/Math.max(1,n);g.method_25294(x,y,x+1,y+1,color);}}
}
