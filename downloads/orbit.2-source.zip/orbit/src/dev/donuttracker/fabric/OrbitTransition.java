package dev.donuttracker.fabric;
import java.util.function.LongSupplier;
/** A single root-menu transition. Init/resize and module navigation never restart it. */
final class OrbitTransition {
 static final long OPEN_NS=280_000_000L,CLOSE_NS=180_000_000L;
 private final boolean animated;private final LongSupplier clock;private boolean started,closing;private long openedAt,closedAt;private float closeFrom;
 OrbitTransition(boolean animated,LongSupplier clock){this.animated=animated;this.clock=clock;}
 private static float smooth(long elapsed,long duration){float t=(float)Math.clamp(elapsed/(double)duration,0,1);return t*t*(3-2*t);}
 float value(){long now=clock.getAsLong();if(!started){started=true;openedAt=now;}
  if(!animated)return closing?0:1;
  if(closing)return closeFrom*(1-smooth(now-closedAt,CLOSE_NS));
  return .04f+.96f*smooth(now-openedAt,OPEN_NS);
 }
 void close(){if(closing)return;closeFrom=value();closedAt=clock.getAsLong();closing=true;}
 boolean closing(){return closing;}
 boolean ready(){return !closing&&(!animated||(started&&clock.getAsLong()-openedAt>=OPEN_NS));}
 boolean finished(){return closing&&(!animated||clock.getAsLong()-closedAt>=CLOSE_NS);}
}
