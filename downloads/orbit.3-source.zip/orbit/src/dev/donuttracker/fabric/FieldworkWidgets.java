package dev.donuttracker.fabric;
import net.minecraft.*;
public final class FieldworkWidgets {
 public static void draw(MenuWidgets.Action b,class_332 g,int mx,int my,float delta){
  if(b instanceof OrbitModuleButton f){g.method_51448().pushMatrix();g.method_51448().translate(f.fractionX(),f.fractionY());drawBody(b,g,mx,my,delta);g.method_51448().popMatrix();}
  else drawBody(b,g,mx,my,delta);
 }
 private static void drawBody(MenuWidgets.Action b,class_332 g,int mx,int my,float delta){
  int x=b.method_46426(),y=b.method_46427(),w=b.method_25368(),h=b.method_25364();boolean active=b.field_22763,chosen=b.selected.getAsBoolean(),hover=b.method_25367(),focus=b.method_25370();
  boolean primary=b.kind==MenuWidgets.Kind.PRIMARY,nav=b.kind==MenuWidgets.Kind.NAV;
  int accent=CoastalStyle.accent(),bg=primary?accent:CoastalStyle.surface(),fg=primary?CoastalStyle.primaryInk():CoastalStyle.ink();
  if(!active){bg=CoastalStyle.panel();fg=CoastalStyle.muted();}else if(hover||chosen)bg=primary?AtelierVisuals.mix(accent,CoastalStyle.ink(),.1f):CoastalStyle.hover();
  OrbitShapes.pill(g,x,y,w,h,active&&(hover||focus||chosen)?accent:CoastalStyle.line());OrbitShapes.pill(g,x+1,y+1,Math.max(1,w-2),Math.max(1,h-2),bg);
  if(focus&&active)OrbitShapes.pill(g,x+4,y+h-4,Math.max(1,w-8),1,primary?fg:accent);
  float s=Math.min(1,h/22f);String label=b.method_25369().getString();int space=w-12;
  if(nav&&w>65){AtelierVisuals.nav(g,label,x+7,y+(h-10)/2,accent);space-=14;}
  float fit=Math.max(.1f,Math.min(s,Math.max(1,space)/(float)Math.max(1,class_310.method_1551().field_1772.method_1727(label))));
  int tx=nav&&w>65?x+23:x+(w-Math.round(class_310.method_1551().field_1772.method_1727(label)*fit))/2;
  if(b.illustration>=0){int cx=x+w/2;OrbitShapes.pill(g,cx-12,y+4,24,5,accent);if(b.illustration!=2)OrbitShapes.pill(g,cx-8,y+11,16,2,CoastalStyle.muted());}
  TrackerHud.scaled(g,label,tx,b.illustration>=0?y+h-11:y+(h-Math.round(8*fit))/2,fit,fg);
 }
}
