package dev.donuttracker.fabric;
/** A bounded, phase-offset bob around an immutable layout anchor. */
final class OrbitModuleButton extends MenuWidgets.Action {
 final int anchorX,anchorY;private final float responsiveScale;private float dx,dy;private double lastTime=Double.NaN;
 OrbitModuleButton(int x,int y,int w,int h,String label,Runnable action,float responsiveScale){
  super(x,y,w,h,label,CoastalStyle::accent,MenuWidgets.Kind.SECONDARY,action);anchorX=x;anchorY=y;this.responsiveScale=responsiveScale;
 }
 void floatAt(int index,double seconds,int pointerX,int pointerY,boolean freeze){
  boolean hovered=field_22763&&pointerX>=method_46426()-3&&pointerX<method_46426()+method_25368()+3&&pointerY>=method_46427()-3&&pointerY<method_46427()+method_25364()+3;
  double elapsed=Double.isNaN(lastTime)?Double.NaN:Math.clamp(seconds-lastTime,0,.1);lastTime=seconds;
  if(freeze||hovered||method_25370())return;
  // Different slow periods avoid a synchronized marching motion; absolute anchors prevent drift.
  float targetX=(float)(Math.sin(seconds*Math.PI*2/6.4+index*.91)*1.5*responsiveScale),targetY=(float)(Math.sin(seconds*Math.PI*2/4.8+index*1.17)*2.0*responsiveScale);
  float follow=Double.isNaN(elapsed)?1:(float)(1-Math.exp(-elapsed/.18));
  dx+=(targetX-dx)*follow;dy+=(targetY-dy)*follow;
  method_46421(anchorX+Math.round(dx));method_46419(anchorY+Math.round(dy));
 }
 float fractionX(){return dx-Math.round(dx);}float fractionY(){return dy-Math.round(dy);}
 float offsetX(){return dx;}float offsetY(){return dy;}
}
