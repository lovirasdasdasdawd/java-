import sys,zipfile,json,hashlib,pathlib
with zipfile.ZipFile(sys.argv[1]) as before,zipfile.ZipFile(sys.argv[2]) as after:
 assert after.testzip() is None
 assert len(after.namelist())==len(set(after.namelist())), 'Duplicate JAR entries'
 meta=json.loads(after.read('fabric.mod.json'));assert meta['id']=='donuttracker' and meta['version']=='1.21.0+orbit.3'
 for cls in ['dev/donuttracker/core/Tracker.class','dev/donuttracker/core/PaymentQueue.class','dev/donuttracker/core/ChatParser.class','dev/donuttracker/core/ReturnPayments.class','dev/auctionmod/AuctionState.class','dev/auctionmod/PaymentParser.class','dev/donuttracker/fabric/mixin/LocalCapeMixin.class','dev/donuttracker/fabric/mixin/CapeGlowMixin.class']:
  assert before.read(cls)==after.read(cls),'Unexpected logic change: '+cls
 assert not any(n.startswith(('net/minecraft/','org/joml/','org/objectweb/')) for n in after.namelist()),'Build/test stub leaked into release'
 for name in ['fieldwork_compass','fieldwork_antlers']:
  item=json.loads(after.read(f'assets/donuttracker/items/{name}.json'))
  assert item['model']=={'type':'minecraft:model','model':f'donuttracker:item/{name}'}
  model=json.loads(after.read(f'assets/donuttracker/models/item/{name}.json'))
  for e in model['elements']:
   assert all(0<=a<b<=16 for a,b in zip(e['from'],e['to']))
   for face in e['faces'].values():assert face['texture']=='#palette' and all(0<=v<=16 for v in face['uv'])
  for texture in model['textures'].values():
   ns,path=texture.split(':',1);assert f'assets/{ns}/textures/{path}.png' in after.namelist()
 print('PASS: JAR integrity, original core logic/mixins preserved, no test stubs, 2 model definitions and their texture references.')
p=pathlib.Path(sys.argv[2]);p.with_suffix('.jar.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
