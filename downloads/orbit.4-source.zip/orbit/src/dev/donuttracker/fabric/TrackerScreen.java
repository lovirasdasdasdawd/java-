package dev.donuttracker.fabric;
import dev.donuttracker.core.*;import net.minecraft.*;
/** Donut navigation wheel with floating readouts. All coordinates share one responsive transform. */
final class TrackerScreen extends class_437 {
 private final DonutTrackerClient mod;private final class_437 parent;private float scale;private int x,y;private final OrbitTransition transition;private final java.util.function.LongSupplier clock;private final long floatEpoch;
 TrackerScreen(DonutTrackerClient mod,class_437 parent){this(mod,parent,false);}
 TrackerScreen(DonutTrackerClient mod,class_437 parent,boolean animate){this(mod,parent,animate,System::nanoTime);}
 TrackerScreen(DonutTrackerClient mod,class_437 parent,boolean animate,java.util.function.LongSupplier clock){super(class_2561.method_43470("Orbit / Donut Tracker"));this.mod=mod;this.parent=parent;this.clock=clock;floatEpoch=clock.getAsLong();transition=new OrbitTransition(animate,clock);}
 private final java.util.List<MenuWidgets.Action> controls=new java.util.ArrayList<>();
 private void enableControls(){boolean ready=transition.ready();for(MenuWidgets.Action b:controls){b.field_22763=ready;OrbitFeedback.transitionBlocked(b,!ready);}}
 public boolean method_25421(){return false;}
 protected void method_25426(){
  controls.clear();
  scale=Math.min(1f,Math.min(Math.max(1,field_22789-16)/560f,Math.max(1,field_22790-16)/300f));x=Math.round((field_22789-560*scale)/2);y=Math.round((field_22790-300*scale)/2);
  String[] labels={"Tracker","Payments","Auctions","Capes","Style","HUDs"};
  Runnable[] actions={()->field_22787.method_1507(new ModuleSettingsScreen(mod,this,false)),()->field_22787.method_1507(new ModuleSettingsScreen(mod,this,true)),()->mod.auctions.openScreen(this),()->field_22787.method_1507(new CapesScreen(mod,this)),()->field_22787.method_1507(new AtmosphereScreen(mod,this)),()->field_22787.method_1507(new HudEditorScreen(mod,this))};
  for(int i=0;i<6;i++){double a=-Math.PI/2+i*Math.PI/3;int xx=(int)Math.round(137+Math.cos(a)*91)-36,yy=(int)Math.round(149+Math.sin(a)*83)-12;button(xx,yy,72,24,labels[i],actions[i],false,true);}
  button(294,244,150,28,mod.tracker.running()?"End session":"Start session",()->{mod.sessionCommand(!mod.tracker.running());method_41843();},true);
  button(480,13,64,22,"Close",this::method_25419,false);
 }
 private void button(int xx,int yy,int w,int h,String label,Runnable action,boolean primary){button(xx,yy,w,h,label,action,primary,false);}
 private void button(int xx,int yy,int w,int h,String label,Runnable action,boolean primary,boolean floating){
  int bx=x+Math.round(xx*scale),by=y+Math.round(yy*scale),bw=Math.max(1,Math.round(w*scale)),bh=Math.max(1,Math.round(h*scale));
  Runnable guarded=()->{if(transition.ready())action.run();};
  MenuWidgets.Action b=floating?new OrbitModuleButton(bx,by,bw,bh,label,guarded,scale):new MenuWidgets.Action(bx,by,bw,bh,label,CoastalStyle::accent,primary?MenuWidgets.Kind.PRIMARY:MenuWidgets.Kind.SECONDARY,guarded);
  b.field_22763=transition.ready();OrbitFeedback.transitionBlocked(b,!transition.ready());controls.add(b);method_37063(b);
 }
 private void text(class_332 g,String s,int xx,int yy,float max,int width,int c){TrackerHud.scaled(g,s,xx,yy,Math.min(max,width/(float)Math.max(1,field_22793.method_1727(s))),c);}
 private void centered(class_332 g,String s,int cx,int yy,float max,int width,int c){float f=Math.min(max,width/(float)Math.max(1,field_22793.method_1727(s)));TrackerHud.scaled(g,s,cx-Math.round(field_22793.method_1727(s)*f/2),yy,f,c);}
 public void method_25394(class_332 g,int mx,int my,float delta){
  if(transition.finished()){field_22787.method_1507(parent);return;}
  float pop=transition.value();enableControls();
  CoastalStyle.configure(mod.settings);CoastalStyle.background(g,field_22789,field_22790);
  float centerX=field_22789/2f,centerY=field_22790/2f;
  int pointerX=Math.round(centerX+(mx-centerX)/Math.max(.001f,pop)),pointerY=Math.round(centerY+(my-centerY)/Math.max(.001f,pop));
  double floatingTime=(clock.getAsLong()-floatEpoch)/1e9;
  for(int i=0;i<controls.size();i++)if(controls.get(i) instanceof OrbitModuleButton b)b.floatAt(i,floatingTime,pointerX,pointerY,transition.closing());
  g.method_51448().pushMatrix();g.method_51448().translate(centerX,centerY);g.method_51448().scale(pop,pop);g.method_51448().translate(-centerX,-centerY);
  int ink=CoastalStyle.ink(),muted=CoastalStyle.muted(),accent=CoastalStyle.accent(),line=CoastalStyle.line();
  g.method_51448().pushMatrix();g.method_51448().translate(x,y);g.method_51448().scale(scale,scale);
  AtelierVisuals.icon(g,17,18,accent,AtelierVisuals.DONUT);text(g,"ORBIT",35,18,1.2f,90,ink);text(g,"DONUT TRACKER",111,21,.62f,170,muted);
  OrbitShapes.ring(g,137,149,86,1,AtelierVisuals.mix(CoastalStyle.panel(),line,.45f));
  for(int i=0;i<6;i++){double a=-Math.PI/2+i*Math.PI/3;int xx=(int)(137+Math.cos(a)*63),yy=(int)(149+Math.sin(a)*63);OrbitShapes.dash(g,xx,yy,(int)(137+Math.cos(a)*72),(int)(149+Math.sin(a)*72),line);}
  OrbitShapes.disc(g,137,151,58,0x40000000);OrbitShapes.disc(g,137,149,58,CoastalStyle.panel());OrbitShapes.ring(g,137,149,57,3,line);
  double phase=mod.tracker.running()?System.nanoTime()/1e9*.12:0;
  OrbitShapes.arc(g,137,149,56,-2.5+phase,3.8,accent);OrbitShapes.arc(g,137,149,51,1.0+phase,.8,AtelierVisuals.mix(accent,ink,.25f));
  centered(g,"THIS SESSION",137,126,.62f,86,muted);centered(g,Money.signed(mod.tracker.profit()),137,143,1.5f,94,CoastalStyle.value(mod.tracker.profit().signum()<0,mod.tracker.profit().signum()<0?mod.settings.profit.negative:mod.settings.profit.positive));
  centered(g,mod.tracker.running()?"RECORDING":"STANDBY",137,169,.58f,85,accent);
  text(g,"SESSION TELEMETRY",294,65,.65f,240,muted);
  text(g,Money.signed(mod.tracker.profit()),292,84,2.3f,244,CoastalStyle.value(mod.tracker.profit().signum()<0,mod.tracker.profit().signum()<0?mod.settings.profit.negative:mod.settings.profit.positive));
  OrbitShapes.pill(g,294,118,104,24,CoastalStyle.surface());AtelierVisuals.clock(g,303,125,accent);text(g,mod.tracker.duration(),318,126,.78f,75,ink);
  text(g,Money.signed(mod.tracker.perHour())+" /h",409,126,.85f,128,ink);
  OrbitShapes.arc(g,275,148,7,-1.3,2.6,line);
  text(g,"PAYMENT QUEUE",294,166,.65f,140,muted);text(g,mod.queue.waiting()+" waiting",468,166,.65f,70,accent);
  var a=mod.queue.active();text(g,a==null?"All clear":a.player(),294,184,1.15f,154,ink);if(a!=null)text(g,"+"+Money.format(a.amount()),458,186,.9f,79,CoastalStyle.value(false,mod.settings.queue.positive));
  text(g,mod.queue.waiting()>0?"NEXT / "+mod.queue.all().get(1).player():"Ready for the next player",294,207,.72f,243,muted);
  text(g,"BALANCE / "+(mod.tracker.hasBalance()?Money.format(mod.tracker.balance()):"Not read yet"),294,282,.68f,240,muted);
  centered(g,"PICK A MODULE",137,266,.62f,180,muted);
  g.method_51448().popMatrix();
  super.method_25394(g,pointerX,pointerY,delta);g.method_51448().popMatrix();
 }
 public boolean method_25404(class_11908 e){if(e.comp_4795()==344||e.comp_4795()==256){method_25419();return true;}if(!transition.ready())return true;return super.method_25404(e);}
 public void method_25419(){if(transition.closing())return;mod.save();transition.close();enableControls();if(transition.finished())field_22787.method_1507(parent);}
}
