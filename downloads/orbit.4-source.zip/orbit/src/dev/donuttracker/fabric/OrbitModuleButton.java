package dev.donuttracker.fabric;
/** Critically damped, subpixel motion around an immutable anchor. */
final class OrbitModuleButton extends MenuWidgets.Action {
 final int anchorX,anchorY;private final float responsiveScale;private double dx,dy,vx,vy,lastTime=Double.NaN,holdX,holdY;private boolean holding;
 private static final double OMEGA=11;
 OrbitModuleButton(int x,int y,int w,int h,String label,Runnable action,float responsiveScale){super(x,y,w,h,label,CoastalStyle::accent,MenuWidgets.Kind.SECONDARY,action);anchorX=x;anchorY=y;this.responsiveScale=responsiveScale;}
 void floatAt(int index,double seconds,int pointerX,int pointerY,boolean freeze){
  boolean hover=field_22763&&pointerX>=method_46426()-3&&pointerX<method_46426()+method_25368()+3&&pointerY>=method_46427()-3&&pointerY<method_46427()+method_25364()+3;
  double elapsed=Double.isNaN(lastTime)?0:Math.max(0,Math.min(seconds-lastTime,.12));lastTime=seconds;
  if(freeze){vx=0;vy=0;return;}
  boolean hold=hover||method_25370();
  if(hold&&!holding){holdX=Math.clamp(dx+vx/OMEGA,-1.5*responsiveScale,1.5*responsiveScale);holdY=Math.clamp(dy+vy/OMEGA,-2*responsiveScale,2*responsiveScale);}holding=hold;
  // Substeps sample the moving target consistently at 30, 60 and 144 FPS.
  int steps=Math.max(1,(int)Math.ceil(elapsed*240));double dt=elapsed/steps;
  for(int step=0;step<steps;step++){
   double sampleTime=seconds-elapsed+(step+1)*dt;
   double tx=hold?holdX:Math.sin(sampleTime*Math.PI*2/8.8+index*.91)*1.5*responsiveScale;
   double ty=hold?holdY:Math.sin(sampleTime*Math.PI*2/6.8+index*1.17)*2*responsiveScale;
   double exp=Math.exp(-OMEGA*dt),jx=dx-tx,jy=dy-ty,kx=vx+OMEGA*jx,ky=vy+OMEGA*jy;
   dx=tx+(jx+kx*dt)*exp;dy=ty+(jy+ky*dt)*exp;vx=(vx-OMEGA*kx*dt)*exp;vy=(vy-OMEGA*ky*dt)*exp;
  }
  double limitX=1.5*responsiveScale,limitY=2*responsiveScale;
  if(Math.abs(dx)>limitX){dx=Math.clamp(dx,-limitX,limitX);vx=0;}if(Math.abs(dy)>limitY){dy=Math.clamp(dy,-limitY,limitY);vy=0;}
  method_46421(anchorX+(int)Math.round(dx));method_46419(anchorY+(int)Math.round(dy));
 }
 float fractionX(){return (float)(dx-Math.round(dx));}float fractionY(){return (float)(dy-Math.round(dy));}
 float offsetX(){return (float)dx;}float offsetY(){return (float)dy;}
 double velocityX(){return vx;}double velocityY(){return vy;}
}
