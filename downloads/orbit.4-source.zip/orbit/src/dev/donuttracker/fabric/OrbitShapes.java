package dev.donuttracker.fabric;
import net.minecraft.class_332;import java.util.*;
/** Cached scanline geometry with vertically merged fills; no shaders or textures. */
public final class OrbitShapes {
 private record Key(int kind,int a,int b,long start,long length){}
 private static final Map<Key,int[]> geometry=new LinkedHashMap<>(96,.75f,true){protected boolean removeEldestEntry(Map.Entry<Key,int[]> e){return size()>96;}};
 private static int[] cached(Key key,java.util.function.Supplier<int[]> make){int[] value=geometry.get(key);if(value==null){value=make.get();geometry.put(key,value);}return value;}
 private static void draw(class_332 g,int x,int y,int color,int[] rects){for(int i=0;i<rects.length;i+=4)g.method_25294(x+rects[i],y+rects[i+1],x+rects[i+2],y+rects[i+3],color);}
 private static int[] flat(List<int[]> rectangles){int[] out=new int[rectangles.size()*4];for(int i=0;i<rectangles.size();i++)System.arraycopy(rectangles.get(i),0,out,i*4,4);return out;}
 public static void pill(class_332 g,int x,int y,int w,int h,int color){if(w<1||h<1)return;
  int[] rects=cached(new Key(0,w,h,0,0),()->{List<int[]> list=new ArrayList<>();double radius=Math.min(w,h)/2.0;int[] previous=null;
   for(int row=0;row<h;row++){double d=Math.max(0,radius-Math.min(row+.5,h-row-.5));int inset=(int)Math.ceil(radius-Math.sqrt(Math.max(0,radius*radius-d*d)));if(w<=inset*2)continue;
    if(previous!=null&&previous[0]==inset&&previous[2]==w-inset&&previous[3]==row)previous[3]=row+1;else{previous=new int[]{inset,row,w-inset,row+1};list.add(previous);}}
   return flat(list);});draw(g,x,y,color,rects);
 }
 public static void disc(class_332 g,int x,int y,int radius,int color){pill(g,x-radius,y-radius,radius*2,radius*2,color);}
 private static int[] merge(TreeMap<Integer,BitSet> rows,int offset){List<int[]> done=new ArrayList<>();Map<Long,int[]> active=new HashMap<>();int previousRow=Integer.MIN_VALUE;
  for(var entry:rows.entrySet()){int y=entry.getKey();if(y!=previousRow+1){done.addAll(active.values());active.clear();}Map<Long,int[]> next=new HashMap<>();BitSet bits=entry.getValue();
   for(int start=bits.nextSetBit(0);start>=0;){int end=bits.nextClearBit(start);long key=((long)start<<32)|(end&0xffffffffL);int[] rect=active.remove(key);if(rect==null)rect=new int[]{start-offset,y,end-offset,y+1};else rect[3]=y+1;next.put(key,rect);start=bits.nextSetBit(end);}
   done.addAll(active.values());active=next;previousRow=y;
  }done.addAll(active.values());return flat(done);
 }
 public static void ring(class_332 g,int x,int y,int radius,int thick,int color){if(radius<1||thick<1)return;
  int[] rects=cached(new Key(1,radius,thick,0,0),()->{int inner=Math.max(0,radius-thick),offset=radius+2;TreeMap<Integer,BitSet> rows=new TreeMap<>();
   for(int yy=-radius;yy<radius;yy++){double dy=yy+.5;int outside=(int)Math.floor(Math.sqrt(Math.max(0,radius*radius-dy*dy))),inside=Math.abs(dy)<inner?(int)Math.floor(Math.sqrt(Math.max(0,inner*inner-dy*dy))):0;if(outside<=0)continue;BitSet bits=new BitSet();if(inside==0)bits.set(offset-outside,offset+outside);else{bits.set(offset-outside,offset-inside);bits.set(offset+inside,offset+outside);}rows.put(yy,bits);}return merge(rows,offset);});draw(g,x,y,color,rects);
 }
 public static void arc(class_332 g,int x,int y,int radius,double start,double length,int color){
  int steps=Math.max(1,(int)Math.ceil(Math.abs(length)*Math.max(1,radius)/1.1));
  if(radius<128){for(int i=0;i<=steps;i++){double a=start+length*i/steps;int xx=(int)Math.round(x+Math.cos(a)*radius),yy=(int)Math.round(y+Math.sin(a)*radius);g.method_25294(xx-1,yy-1,xx+1,yy+1,color);}return;}
  int[] rects=cached(new Key(2,radius,0,Double.doubleToLongBits(start),Double.doubleToLongBits(length)),()->{int offset=radius+3;TreeMap<Integer,BitSet> rows=new TreeMap<>();
   for(int i=0;i<=steps;i++){double a=start+length*i/steps;int xx=(int)Math.round(Math.cos(a)*radius),yy=(int)Math.round(Math.sin(a)*radius);for(int dy=-1;dy<1;dy++)rows.computeIfAbsent(yy+dy,k->new BitSet()).set(xx-1+offset,xx+1+offset);}return merge(rows,offset);});draw(g,x,y,color,rects);
 }
 public static void dash(class_332 g,int x1,int y1,int x2,int y2,int color){int n=Math.max(Math.abs(x2-x1),Math.abs(y2-y1));for(int i=0;i<=n;i+=3){int x=x1+(x2-x1)*i/Math.max(1,n),y=y1+(y2-y1)*i/Math.max(1,n);g.method_25294(x,y,x+1,y+1,color);}}
}
