package dev.donuttracker.fabric;
import net.minecraft.class_332;

/** Pixel-aligned rendering primitives. No game state, networking or configuration writes. */
public final class AtelierVisuals {
    private AtelierVisuals() {}
    public static final String[] DONUT={"...55555...","..5666665..",".566222665.","5622...2265","562.....265","562.....265","5622...2265",".566222665.","..5666665..","...55555..."};
    public static final String[] PEOPLE={".111..111..",".111..111..",".111..111..","...........","11111.11111","11111.11111","11111.11111","11111.11111"};
    public static final String[] CLOCK={"...11111...","..1.....1..",".1...1...1.","1....1....1","1....1....1","1....111..1",".1.......1.","..1.....1..","...11111..."};
    public static final String[] CHART={"........1..",".......111.","......11111",".....11.1..","..1.11.....",".1111......","11.1.......","...........","11111111111"};
    public static final String[] CAPE={"..1111111..",".111...111.","11.......11","11...1...11","11..111..11","11.11111.11","11..111..11","11...1...11","11.......11","11111111111"};
    public static final String[] GAVEL={".....111...","....11111..","...11111...","....111....","...11......","..11.......",".11........","...........","..11111111.",".1111111111"};
    public static final String[] MOVE={".....1.....","....111....",".....1.....","..1..1..1..",".111111111.","..1..1..1..",".....1.....","....111....",".....1....."};
    public static final String[] SUN={".....1.....",".1.......1.","....111....","...11111...","1..11111..1","...11111...","....111....",".1.......1.",".....1....."};
    public static void icon(class_332 g,int x,int y,int c,String[] rows) {
        for(int yy=0;yy<rows.length;yy++) for(int xx=0;xx<rows[yy].length();xx++) {
            char p=rows[yy].charAt(xx); if(p=='.') continue;
            int shade=p=='5'?mix(c,0xff10151d,.45f):p=='6'?mix(c,0xffffffff,.25f):c;
            g.method_25294(x+xx,y+yy,x+xx+1,y+yy+1,shade);
        }
    }
    public static void donut(class_332 g,int x,int y,int c){icon(g,x,y,c,DONUT);}
    public static void people(class_332 g,int x,int y,int c){icon(g,x,y,c,PEOPLE);}
    public static void clock(class_332 g,int x,int y,int c){icon(g,x,y,c,CLOCK);}
    public static int mix(int a,int b,float t){int c=0xff000000;for(int s:new int[]{16,8,0})c|=Math.round(((a>>>s)&255)*(1-t)+((b>>>s)&255)*t)<<s;return c;}
    public static void rounded(class_332 g,int x,int y,int r,int b,int c,int radius){soft(g,x,y,r-x,b-y,c,Math.min(12,Math.max(0,radius)));}
    public static void border(class_332 g,int x,int y,int r,int b,int c,int radius){
        if(r<=x||b<=y)return;
        // One-pixel curved outline; leave the interior untouched.
        int w=r-x,h=b-y;double rad=Math.min(Math.min(w,h)/2.0,Math.max(2,radius));
        for(int yy=0;yy<h;yy++){double d=Math.max(0,rad-Math.min(yy+.5,h-yy-.5));int inset=(int)Math.ceil(rad-Math.sqrt(Math.max(0,rad*rad-d*d)));if(w<=inset*2)continue;
            if(yy==0||yy==h-1)g.method_25294(x+inset,y+yy,r-inset,y+yy+1,c);
            else{g.method_25294(x+inset,y+yy,x+inset+1,y+yy+1,c);g.method_25294(r-inset-1,y+yy,r-inset,y+yy+1,c);}}
    }
    public static void panel(class_332 g,int x,int y,int w,int h,int base,int line,int accent,int alpha){
        // Shared submenus retain their layout inside a softly curved panel.
        soft(g,x+2,y+4,w,h,0x40000000,16);soft(g,x,y,w,h,(alpha<<24)|(base&0xffffff),16);border(g,x,y,x+w,y+h,0xff000000|(line&0xffffff),16);
    }
    public static void soft(class_332 g,int x,int y,int w,int h,int c,int radius){
        if(w<1||h<1)return;double rad=Math.min(radius,Math.min(w,h)/2.0);
        for(int yy=0;yy<h;yy++){double d=Math.max(0,rad-Math.min(yy+.5,h-yy-.5));int in=(int)Math.ceil(rad-Math.sqrt(Math.max(0,rad*rad-d*d)));if(w>in*2)g.method_25294(x+in,y+yy,x+w-in,y+yy+1,c);}
    }
    public static void backdrop(class_332 g,int x,int y,int w,int h,boolean motion,float strength,int tint,double speed,double density){
        g.method_25294(x,y,x+w,y+h,0xe80c1017);
        int radius=Math.max(w,h)/2;
        OrbitShapes.arc(g,x+w/4,y+h/2,radius,-1.5,3.1,0x122b3a50);
        OrbitShapes.arc(g,x+w/4,y+h/2,radius+22,-1.5,3.1,0x102b3a50);
    }
    public static int value(boolean loss,int custom,dev.donuttracker.core.Settings.MenuPalette palette){
        if(palette==dev.donuttracker.core.Settings.MenuPalette.AURORA||palette==dev.donuttracker.core.Settings.MenuPalette.PAPER)return palette==dev.donuttracker.core.Settings.MenuPalette.PAPER?(loss?0xffa33727:0xff375845):(loss?0xffef9895:0xffb4d49d);
        return 0xff000000|custom;
    }
    public static int controlAccent(int custom,dev.donuttracker.core.Settings.MenuPalette palette){
        if(palette==dev.donuttracker.core.Settings.MenuPalette.AURORA)return 0xffedab7a;
        if(palette==dev.donuttracker.core.Settings.MenuPalette.PAPER)return 0xff328277;
        return 0xff000000|custom;
    }
    public static void nav(class_332 g,String label,int x,int y,int c){
        String[] pixels=switch(label){case "Tracker"->CHART;case "Payments"->PEOPLE;case "Auctions"->GAVEL;case "Capes"->CAPE;case "Move HUDs"->MOVE;case "Atmosphere"->SUN;default->null;};
        if(pixels!=null)icon(g,x,y,c,pixels);
    }
}
