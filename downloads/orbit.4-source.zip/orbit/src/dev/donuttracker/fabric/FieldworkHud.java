package dev.donuttracker.fabric;
import dev.donuttracker.core.*;import net.minecraft.*;
public final class FieldworkHud {
 public static int height(Settings.Hud h){return h.layout==Settings.Layout.MINIMAL?44:h.layout==Settings.Layout.STACKED?112:78;}
 private static int ink(int c){return 0xff000000|c;}
 private static int alpha(int c,int a){return (a<<24)|(c&0xffffff);}
 private static void text(class_332 g,String s,int x,int y,float scale,int c,int width){float fit=Math.min(scale,width/(float)Math.max(1,class_310.method_1551().field_1772.method_1727(s)));TrackerHud.scaled(g,s,x,y,fit,c);}
 private static void right(class_332 g,String s,int x,int y,float scale,int c,int width){float f=Math.min(scale,width/(float)Math.max(1,class_310.method_1551().field_1772.method_1727(s)));TrackerHud.scaled(g,s,x-Math.round(class_310.method_1551().field_1772.method_1727(s)*f),y,f,c);}
 public static void draw(class_332 g,DonutTrackerClient mod,Settings.Hud h,boolean payment,boolean editing){
  if(!h.enabled&&!editing)return;int bg=ink(h.background),fg=ink(h.text),accent=ink(h.accent),muted=AtelierVisuals.mix(bg,fg,.68f),line=AtelierVisuals.mix(bg,fg,.16f);
  boolean minimal=h.layout==Settings.Layout.MINIMAL;int cy=minimal?22:27,bodyY=minimal?2:7,bodyH=40;
  int a=(int)(Math.clamp(h.opacity,0,1)*(h.theme==Settings.Theme.GLASS?182:246));int bodyX=h.showIcon?20:0,start=h.showIcon?54:14,available=208-start;
  g.method_51448().pushMatrix();g.method_51448().translate(TrackerHud.x(h,g.method_51421()),TrackerHud.y(h,g.method_51443()));g.method_51448().scale((float)h.scale,(float)h.scale);
  OrbitShapes.pill(g,bodyX+1,bodyY+3,219-bodyX,bodyH,0x30000000);OrbitShapes.pill(g,bodyX,bodyY,220-bodyX,bodyH,alpha(line,a));OrbitShapes.pill(g,bodyX+1,bodyY+1,218-bodyX,bodyH-2,alpha(bg,a));
  if(h.showIcon){OrbitShapes.disc(g,24,cy+2,24,0x30000000);OrbitShapes.disc(g,24,cy,24,alpha(bg,a));OrbitShapes.ring(g,24,cy,23,1,alpha(line,a));OrbitShapes.arc(g,24,cy,22,-2.3,mod.tracker.running()||payment?4.5:1.4,alpha(accent,a));AtelierVisuals.icon(g,19,cy-5,accent,payment?AtelierVisuals.PEOPLE:AtelierVisuals.DONUT);}
  if(h.showIcon&&h.theme==Settings.Theme.NEON)OrbitShapes.arc(g,24,cy,24,-2.3,4.5,alpha(accent,a/2));
  var active=mod.queue.active();
  if(minimal){
   if(payment){text(g,active==null?"No payments":active.player(),start,9,.74f,fg,available);if(active!=null)text(g,"+"+Money.format(active.amount()),start,23,1.0f,ink(h.positive),available);}
   else{if(h.showProfit)text(g,Money.signed(mod.tracker.profit()),start,14,1.35f,ink(mod.tracker.profit().signum()<0?h.negative:h.positive),h.showTimer?available-62:available);if(h.showTimer)right(g,mod.tracker.duration(),207,18,.63f,muted,62);}
  }else{
   text(g,payment?"PAYMENTS":"NET PROFIT",start,13,.62f,muted,available-40);right(g,payment?mod.queue.waiting()+" NEXT":mod.tracker.running()?"LIVE":"IDLE",207,13,.58f,accent,36);
   if(payment){text(g,active==null?"All clear":active.player(),start,27,.95f,fg,available-68);if(active!=null)right(g,"+"+Money.format(active.amount()),207,28,.95f,ink(h.positive),65);}
   else if(h.showProfit)text(g,Money.signed(mod.tracker.profit()),start,26,1.65f,ink(mod.tracker.profit().signum()<0?h.negative:h.positive),available);
   int fx=h.showIcon?42:6,fw=220-fx-3;OrbitShapes.pill(g,fx,54,fw,20,alpha(bg,(int)(a*.87)));
   if(payment){var rows=mod.queue.all();text(g,rows.size()>1?"NEXT  "+rows.get(1).player():"Waiting for a payment",fx+10,61,.65f,muted,fw-62);if(rows.size()>1)right(g,Money.format(rows.get(1).amount()),207,61,.65f,fg,50);
    if(h.layout==Settings.Layout.STACKED){for(int i=2;i<Math.min(4,rows.size());i++){int yy=82+(i-2)*13;text(g,rows.get(i).player(),fx+10,yy,.68f,muted,fw-70);right(g,Money.format(rows.get(i).amount()),207,yy,.68f,fg,62);}}}
   else{if(h.showTimer)text(g,mod.tracker.duration(),fx+10,61,.7f,fg,65);if(h.showRate)right(g,Money.signed(mod.tracker.perHour())+" /h",207,61,.7f,muted,fw-84);
    if(h.layout==Settings.Layout.STACKED){OrbitShapes.pill(g,fx,82,fw,23,alpha(bg,(int)(a*.7)));text(g,"BALANCE",fx+10,90,.6f,muted,60);right(g,mod.tracker.hasBalance()?Money.format(mod.tracker.balance()):"Not read",207,89,.8f,fg,fw-84);}}
  }
  if(editing)OrbitShapes.arc(g,24,cy,24,0,Math.PI*2,accent);
  g.method_51448().popMatrix();
 }
}
