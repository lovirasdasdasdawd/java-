package dev.donuttracker.fabric;
import java.util.*;
/** Weak ownership prevents stale screens from retaining UI animation state. */
final class OrbitFeedback {
 private static final Map<MenuWidgets.Action,State> states=new WeakHashMap<>();
 static final class State {long last;boolean initialized,blocked;float warmth;}
 private static State state(MenuWidgets.Action b){return states.computeIfAbsent(b,k->new State());}
 static void transitionBlocked(MenuWidgets.Action b,boolean blocked){state(b).blocked=blocked;}
 static boolean transitionBlocked(MenuWidgets.Action b){return state(b).blocked;}
 static float warmth(MenuWidgets.Action b,boolean hot){return warmth(b,hot,System.nanoTime());}
 static float warmth(MenuWidgets.Action b,boolean hot,long now){State s=state(b);double dt=s.initialized?Math.clamp((now-s.last)/1e9,0,.12):0;s.initialized=true;s.last=now;s.warmth=follow(s.warmth,hot?1:0,dt);return s.warmth;}
 static float follow(float current,float target,double dt){return (float)(target+(current-target)*Math.exp(-Math.max(0,dt)/.11));}
}
