package dev.donuttracker.fabric;
public class CrashRegression {
 public static void main(String[] args){boolean expectFailure=args.length>0&&args[0].equals("expect-interface-crash");
  try{TrackerScreen s=new TrackerScreen(new DonutTrackerClient(),null);s.method_25426();if(expectFailure)throw new AssertionError("Expected old build to reproduce crash");System.out.println("PASS: corrected Minecraft Text interface allows dashboard construction and initialization.");}
  catch(IncompatibleClassChangeError e){if(!expectFailure||!e.getMessage().contains("InterfaceMethodref"))throw e;System.out.println("PASS: old Fieldwork.1 reproduces the user's InterfaceMethodref crash.");}
 }
}
