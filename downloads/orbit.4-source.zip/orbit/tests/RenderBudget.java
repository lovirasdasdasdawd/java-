package dev.donuttracker.fabric;
import net.minecraft.*;
public class RenderBudget{public static void main(String[]args){TrackerScreen s=new TrackerScreen(new DonutTrackerClient(),null);s.method_25426();class_332 g=new class_332(560,320);s.method_25394(g,-1000,-1000,0);System.out.println((args.length>0?args[0]:"Menu")+" fill calls: "+g.calls);}}
