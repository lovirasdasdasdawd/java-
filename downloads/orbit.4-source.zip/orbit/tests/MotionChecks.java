package dev.donuttracker.fabric;
import net.minecraft.*;import java.util.concurrent.atomic.AtomicLong;import java.awt.geom.Point2D;
public class MotionChecks {
 static int count;static void check(boolean b,String s){count++;if(!b)throw new AssertionError(s);}
 static void near(double a,double b,String s){check(Math.abs(a-b)<.0001,s+": "+a+" / "+b);}
 public static void main(String[] args){
  AtomicLong clock=new AtomicLong();OrbitTransition t=new OrbitTransition(true,clock::get);
  near(t.value(),.04,"Opening starts small");check(!t.ready(),"Opening blocks interaction");float prev=t.value();
  for(int i=1;i<=20;i++){clock.set(OrbitTransition.OPEN_NS*i/20);float v=t.value();check(v>=prev&&v<=1,"Opening grows without overshoot");prev=v;}
  check(t.ready(),"Opening enables input on completion");near(t.value(),1,"Full size at end");t.close();near(t.value(),1,"Close starts at full size");
  long closeAt=clock.get();for(int i=1;i<=20;i++){clock.set(closeAt+OrbitTransition.CLOSE_NS*i/20);float v=t.value();check(v<=prev&&v>=0,"Closing shrinks monotonically");prev=v;t.close();}
  check(t.finished(),"Repeated close requests do not restart timer");near(t.value(),0,"Close reaches zero");
  clock.set(0);t=new OrbitTransition(true,clock::get);t.value();clock.set(OrbitTransition.OPEN_NS/3);float interrupted=t.value();t.close();near(t.value(),interrupted,"Early close reverses without jumping to full size");
  for(int closeMode=0;closeMode<3;closeMode++){
   clock.set(0);DonutTrackerClient mod=new DonutTrackerClient();class_437 parent=new class_437(class_2561.method_43470("parent"));TrackerScreen screen=new TrackerScreen(mod,parent,true,clock::get);screen.method_25426();class_310.method_1551().method_1507(screen);class_332 g=new class_332(560,320);
   screen.method_25394(g,280,160,0);near(screen.childTransforms.get(0).getScaleX(),.04,"Buttons scale with the opening content");check(g.matrices.depth()==0,"Opening balances matrix stack");
   ((MenuWidgets.Action)screen.children.get(6)).run.run();check(!mod.tracker.running(),"Cannot activate session at its old full-size position during animation");
   clock.set(OrbitTransition.OPEN_NS/2);screen.method_25394(g,280,160,0);near(screen.childTransforms.get(0).getScaleX(),.52,"Half-open transform applied to controls");Point2D fixed=screen.childTransforms.get(0).transform(new Point2D.Double(280,160),null);near(fixed.getX(),280,"Screen center X stays fixed");near(fixed.getY(),160,"Screen center Y stays fixed");
   clock.set(OrbitTransition.OPEN_NS);screen.method_25394(g,0,0,0);check(((MenuWidgets.Action)screen.children.get(0)).field_22763,"Controls enabled after opening");near(screen.childTransforms.get(0).getScaleX(),1,"Opening settles at full size");
   ((MenuWidgets.Action)screen.children.get(6)).run.run();screen.method_25394(g,0,0,0);near(screen.childTransforms.get(0).getScaleX(),1,"Resize/refresh does not replay animation");
   ((MenuWidgets.Action)screen.children.get(3)).run.run();check(class_310.method_1551().current instanceof CapesScreen,"Module navigation occurs immediately");class_310.method_1551().method_1507(screen);screen.children.clear();screen.method_25426();screen.method_25394(g,0,0,0);near(screen.childTransforms.get(0).getScaleX(),1,"Returning from a module does not replay opening");
   if(closeMode==0)screen.method_25404(new class_11908(344));else if(closeMode==1)((MenuWidgets.Action)screen.children.get(7)).run.run();else screen.method_25404(new class_11908(256));
   check(class_310.method_1551().current==screen,"Menu remains visible for closing animation");check(!((MenuWidgets.Action)screen.children.get(0)).field_22763,"Closing blocks input");
   clock.set(OrbitTransition.OPEN_NS+OrbitTransition.CLOSE_NS/2);screen.method_25394(g,0,0,0);near(screen.childTransforms.get(0).getScaleX(),.5,"Close shrinks all controls");check(class_310.method_1551().current==screen,"Half-closed menu still visible");
   screen.method_25419();clock.set(OrbitTransition.OPEN_NS+OrbitTransition.CLOSE_NS);screen.method_25394(g,0,0,0);check(class_310.method_1551().current==parent,"Parent restored only after shrink completes");check(g.matrices.depth()==0,"Closing balances matrix stack");
  }
  clock.set(0);TrackerScreen ordinary=new TrackerScreen(new DonutTrackerClient(),null);ordinary.method_25426();class_332 g=new class_332(560,320);ordinary.method_25394(g,0,0,0);near(ordinary.childTransforms.get(0).getScaleX(),1,"Non-hotkey menu construction is immediate");
  System.out.println("PASS: "+count+" deterministic animation assertions; Right Shift, Close and Escape; no replay on resize/module return.");
 }
}
