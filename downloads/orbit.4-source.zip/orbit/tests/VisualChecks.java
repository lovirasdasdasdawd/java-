package dev.donuttracker.fabric;
import dev.donuttracker.core.*;
import net.minecraft.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
public class VisualChecks {
 static int checks;
 static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 static void label(class_332 g,String s,int x,int y,int c){g.method_51433(new class_327(),s,x,y,c,false);}
 public static void main(String[] args)throws Exception {
  Path out=Path.of(args[0]);Files.createDirectories(out.resolve("textures"));
  DonutTrackerClient mod=new DonutTrackerClient();CoastalStyle.configure(mod.settings);
  check(CoastalStyle.panel()==0xff161b23,"New default palette");
  check(mod.settings.profit.background==0x202723,"New HUD default");
  int states=0;
  for(Settings.Layout layout:Settings.Layout.values())for(Settings.Theme theme:Settings.Theme.values())for(int state=0;state<3;state++)for(boolean icons:new boolean[]{true,false}){
   mod=new DonutTrackerClient();mod.settings.profit.layout=layout;mod.settings.queue.layout=layout;mod.settings.profit.theme=theme;mod.settings.queue.theme=theme;mod.settings.profit.showIcon=icons;mod.settings.queue.showIcon=icons;
   mod.settings.queue.x=210;
   if(state>0){mod.tracker.startPayments();mod.tracker.incomingPayment(new BigDecimal(state==1?"1250000":"5"));if(state==2)mod.tracker.outgoingPayment(new BigDecimal("1000000"));
    mod.queue.add("Long_Player_Name",new BigDecimal("1250000"),BigDecimal.ZERO);mod.queue.add("PlayerTwo",new BigDecimal("250000"),BigDecimal.ZERO);mod.queue.add("PlayerThree",new BigDecimal("150000"),BigDecimal.ZERO);mod.queue.add("PlayerFour",new BigDecimal("100000"),BigDecimal.ZERO);}
   class_332 g=new class_332(420,160);TrackerHud.render(g,mod,false);
   check(g.calls>4&&g.textCalls>0,"HUD actually rendered");check(g.matrices.depth()==0,"HUD restores transform stack");states++;
  }
  // Original patched HUD, rendered offscreen with a test drawing adapter.
  mod=new DonutTrackerClient();mod.tracker.startPayments();mod.tracker.incomingPayment(new BigDecimal("1250000"));mod.settings.profit.x=18;mod.settings.profit.y=14;mod.settings.queue.x=246;mod.settings.queue.y=14;
  mod.queue.add("Northstar",new BigDecimal("350000"),BigDecimal.ZERO);mod.queue.add("Oakvale",new BigDecimal("150000"),BigDecimal.ZERO);
  class_332 hud=new class_332(480,112);AtelierVisuals.backdrop(hud,0,0,480,112,false,.6f,0xa9c48a,.1,.3);TrackerHud.render(hud,mod,false);label(hud,"Patched HUD / offscreen adapter",18,94,0xff9baabd);ImageIO.write(hud.image,"png",out.resolve("hud-preview.png").toFile());
  int dashboardSizes=0;
  for(int[] size:new int[][]{{560,320},{540,286},{400,250},{320,200},{854,480}}){
   TrackerScreen screen=new TrackerScreen(mod,null);screen.field_22789=size[0];screen.field_22790=size[1];screen.method_25426();
   class_332 canvas=new class_332(size[0],size[1]);screen.method_25394(canvas,0,0,0);
   check(screen.children.size()==8,"Radial navigation and actions exist");
   for(int i=0;i<screen.children.size();i++)for(int j=i+1;j<screen.children.size();j++){
    MenuWidgets.Action a=(MenuWidgets.Action)screen.children.get(i),b=(MenuWidgets.Action)screen.children.get(j);
    check(!(a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h),"Orbit navigation hit boxes do not overlap");
   }
   for(var child:screen.children){MenuWidgets.Action button=(MenuWidgets.Action)child;check(button.x>=0&&button.y>=0&&button.x+button.w<=size[0]&&button.y+button.h<=size[1],"Button stays inside viewport");}
   check(canvas.matrices.depth()==0,"Dashboard restores matrix stack");check(canvas.textCalls>=15,"Dashboard actually draws data: "+size[0]+"x"+size[1]+" text calls="+canvas.textCalls);dashboardSizes++;
   if(size[0]==560)ImageIO.write(canvas.image,"png",out.resolve("dashboard-preview.png").toFile());
  }
  TrackerScreen screen=new TrackerScreen(mod,null);screen.method_25426();
  MenuWidgets.Action stop=(MenuWidgets.Action)screen.children.get(6);stop.run.run();check(!mod.tracker.running(),"Session button stops session");
  MenuWidgets.Action startButton=(MenuWidgets.Action)screen.children.get(6);startButton.run.run();check(mod.tracker.running(),"Session button starts session");
  ((MenuWidgets.Action)screen.children.get(3)).run.run();check(class_310.method_1551().current instanceof CapesScreen,"Capes navigation");
  ((MenuWidgets.Action)screen.children.get(5)).run.run();check(class_310.method_1551().current instanceof HudEditorScreen,"HUD editor navigation");
  screen.method_25404(new class_11908(344));check(class_310.method_1551().current==null,"Right Shift closes dashboard");
  BufferedImage sheet=new BufferedImage(14*96,188,BufferedImage.TYPE_INT_ARGB);Graphics2D sg=sheet.createGraphics();sg.setColor(new Color(0xff101720,true));sg.fillRect(0,0,sheet.getWidth(),sheet.getHeight());sg.setFont(new Font(Font.MONOSPACED,0,9));int idx=0;
  for(CapePattern.Design d:CapePattern.Design.values()){
   CapeStudio.Textures t=CapeStudio.create(d,0x202723,0xd9754e,0xa9c48a,.45,.15,true,null,144,144,CapeTuning.DEFAULT);
   check(t.cloth().length==1024*512&&t.glow().length==1024*512&&t.preview().length==1024*512,"Cape dimensions");
   CapeStudio.Textures off=CapeStudio.create(d,0x202723,0xd9754e,0xa9c48a,0,0,false,null,144,144,CapeTuning.DEFAULT);
   check(java.util.Arrays.stream(off.glow()).allMatch(p->p==0),"Disabled glow transparent");
   check(java.util.Arrays.stream(t.cloth()).distinct().count()>4,"Cape art present");
   for(int y=0;y<256;y+=11)for(int x=0;x<160;x+=7)check(t.cloth()[(y+16)*1024+16+x]==t.cloth()[(y+16)*1024+192+x],"Matching front/back UV faces");
   BufferedImage texture=new BufferedImage(1024,512,BufferedImage.TYPE_INT_ARGB);texture.setRGB(0,0,1024,512,t.cloth(),0,1024);ImageIO.write(texture,"png",out.resolve("textures/"+d.name().toLowerCase()+".png").toFile());
   sg.drawImage(texture,idx*96+8,12,idx*96+88,140,16,16,176,272,null);sg.setColor(new Color(0xffe6edf3,true));String title=d.name().replace('_',' ');sg.drawString(title,idx*96+5,162);idx++;
  }
  sg.setColor(new Color(0xff9baabd,true));sg.drawString("Fieldwork cape artwork / all 3 original winter designs retained",12,182);sg.dispose();ImageIO.write(sheet,"png",out.resolve("cape-lineup.png").toFile());
  int a=AtelierEmblems.sample(CapePattern.Design.PHOENIX,20,28,0xd9754e,0xa9c48a,new CapeTuning(0,.5,0));int detail=AtelierEmblems.sample(CapePattern.Design.PHOENIX,5,12,0xd9754e,0xa9c48a,new CapeTuning(.5,.5,1));check(detail!=0,"Density adds stitching");
  for(int w=1;w<15;w++)for(int h=1;h<15;h++){class_332 tiny=new class_332(20,20);AtelierVisuals.rounded(tiny,0,0,w,h,0xff000000,12);AtelierVisuals.border(tiny,0,0,w,h,0xffffffff,12);}
  // Business logic smoke checks execute the unchanged original classes.
  Tracker tracker=new Tracker();tracker.startPayments();tracker.incomingPayment(new BigDecimal("100"));tracker.outgoingPayment(new BigDecimal("25"));check(tracker.profit().equals(new BigDecimal("75")),"Tracker calculation");
  PaymentQueue q=new PaymentQueue();check(q.add("Northstar",new BigDecimal("100"),BigDecimal.TEN),"Queue accepts payment");check(!q.add("Oakvale",BigDecimal.ONE,BigDecimal.TEN),"Queue minimum preserved");check(q.next().player().equals("Northstar"),"Queue order");
  System.out.println("PASS: "+states+" HUD states, "+dashboardSizes+" dashboard sizes, 14 cape designs, "+checks+" assertions; previews exported.");
 }
}
