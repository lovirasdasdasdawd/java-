package dev.donuttracker.fabric;
import net.minecraft.*;import java.util.concurrent.atomic.AtomicLong;
public class FloatChecks {
 static int checks;static void check(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
 static void near(double a,double b,String s){check(Math.abs(a-b)<.0001,s);}
 public static void main(String[] args){
  boolean moved=false,differentPhase=false;
  for(float responsive:new float[]{1,.7f,.5f}){
   OrbitModuleButton[] buttons=new OrbitModuleButton[6];for(int i=0;i<6;i++)buttons[i]=new OrbitModuleButton(100+i*90,100,72,24,"Tracker",()->{},responsive);
   for(int frame=0;frame<=720;frame++){
    double time=frame/60.0;
    for(int i=0;i<6;i++){OrbitModuleButton b=buttons[i];b.floatAt(i,time,-1000,-1000,false);check(Math.abs(b.offsetX())<=1.5f*responsive+.0001&&Math.abs(b.offsetY())<=2*responsive+.0001,"Motion stays within 1.5 by 2 pixel envelope");near(b.method_46426()+b.fractionX(),b.anchorX+b.offsetX(),"Draw position follows live X hitbox to subpixel precision");near(b.method_46427()+b.fractionY(),b.anchorY+b.offsetY(),"Draw position follows live Y hitbox to subpixel precision");if(frame>0&&(Math.abs(b.offsetX())>.1||Math.abs(b.offsetY())>.1))moved=true;}
    if(Math.abs(buttons[0].offsetY()-buttons[1].offsetY())>.2)differentPhase=true;
   }
  }
  check(moved,"Buttons visibly float");check(differentPhase,"Different phase per module");
  OrbitModuleButton b=new OrbitModuleButton(100,100,72,24,"Tracker",()->{},1);b.floatAt(2,0,-1000,-1000,false);float x=b.offsetX(),y=b.offsetY();
  b.floatAt(2,5,b.method_46426()+20,b.method_46427()+10,false);near(b.offsetX(),x,"Hover holds X steady");near(b.offsetY(),y,"Hover holds Y steady");
  b.focused=true;b.floatAt(2,6,-1000,-1000,false);near(b.offsetY(),y,"Keyboard focus holds steady");b.focused=false;b.floatAt(2,7,-1000,-1000,true);near(b.offsetX(),x,"Closing freezes motion");
  b.floatAt(2,7.016,-1000,-1000,false);check(Math.abs(b.offsetX()-x)<.3&&Math.abs(b.offsetY()-y)<.35,"Hover release resumes gently");
  for(int[] size:new int[][]{{560,320},{540,286},{400,250},{320,200},{854,480}}){
   AtomicLong clock=new AtomicLong();TrackerScreen screen=new TrackerScreen(new DonutTrackerClient(),null,false,clock::get);screen.field_22789=size[0];screen.field_22790=size[1];screen.method_25426();
   MenuWidgets.Action start=(MenuWidgets.Action)screen.children.get(6),close=(MenuWidgets.Action)screen.children.get(7);int sx=start.x,sy=start.y,cx=close.x,cy=close.y;
   for(int frame=0;frame<24;frame++){clock.set(frame*125_000_000L);class_332 g=new class_332(size[0],size[1]);screen.method_25394(g,-1000,-1000,0);
    for(int i=0;i<6;i++){OrbitModuleButton module=(OrbitModuleButton)screen.children.get(i);check(module.x>=0&&module.y>=0&&module.x+module.w<=size[0]&&module.y+module.h<=size[1],"Floating modules stay within viewport");}
    check(start.x==sx&&start.y==sy&&close.x==cx&&close.y==cy,"Only the six orbiting module buttons float");check(g.matrices.depth()==0,"Fractional drawing restores transform stack");
   }
  }
  System.out.println("PASS: "+checks+" floating-motion assertions; bounded bob, matching hitboxes, hover/focus freeze and smooth resume, five screen sizes.");
 }
}
