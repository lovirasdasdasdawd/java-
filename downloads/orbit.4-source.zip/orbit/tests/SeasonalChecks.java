import java.net.*;import java.nio.file.*;import java.util.*;
public class SeasonalChecks {
 static Object generate(ClassLoader loader,String name)throws Exception {
  Class<?> design=loader.loadClass("dev.donuttracker.core.CapePattern$Design"),tuning=loader.loadClass("dev.donuttracker.core.CapeTuning"),studio=loader.loadClass("dev.donuttracker.core.CapeStudio");
  Object d=Arrays.stream(design.getEnumConstants()).filter(e->e.toString().equals(name)).findFirst().orElseThrow();
  return studio.getMethod("create",design,int.class,int.class,int.class,double.class,double.class,boolean.class,int[].class,int.class,int.class,tuning).invoke(null,d,0x202723,0xd9754e,0xa9c48a,.45,.15,true,null,144,144,tuning.getField("DEFAULT").get(null));
 }
 public static void main(String[] args)throws Exception{
  try(URLClassLoader old=new URLClassLoader(new URL[]{Path.of(args[0]).toUri().toURL()},ClassLoader.getPlatformClassLoader());URLClassLoader now=new URLClassLoader(new URL[]{Path.of(args[1]).toUri().toURL()},ClassLoader.getPlatformClassLoader())){
   for(String name:new String[]{"CHRISTMAS_TREE","WINTER_NIGHT","GINGERBREAD"}){Object a=generate(old,name),b=generate(now,name);for(String part:new String[]{"cloth","glow","preview"})if(!Arrays.equals((int[])a.getClass().getMethod(part).invoke(a),(int[])b.getClass().getMethod(part).invoke(b)))throw new AssertionError(name+" "+part+" unexpectedly changed");}
  }
  System.out.println("PASS: all 3 seasonal capes retain pixel-identical cloth, glow and previews from uploaded 1.21.0.");
 }
}
