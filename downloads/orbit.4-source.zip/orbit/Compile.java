import javax.tools.ToolProvider;
public class Compile {
 public static void main(String[] args){int r=ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,args);if(r!=0)System.exit(r);}
}
