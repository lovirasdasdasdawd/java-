package net.minecraft;
public class class_339 implements class_364 {
 public int x,y,w,h;public boolean field_22763=true,hover=false,focused=false;public class_2561 label=class_2561.method_43470("");
 public void method_46421(int value){x=value;}public void method_46419(int value){y=value;}
 public int method_46426(){return x;}public int method_46427(){return y;}public int method_25368(){return w;}public int method_25364(){return h;}public boolean method_25367(){return hover;}public boolean method_25370(){return focused;}public class_2561 method_25369(){return label;}
}
