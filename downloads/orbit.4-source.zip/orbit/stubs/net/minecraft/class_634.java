package net.minecraft;
public class class_634 {public class_640 method_2874(String s){return null;}}
