package net.minecraft;
public class class_327 {public String method_27523(String s,int width){return s.substring(0,Math.min(s.length(),Math.max(0,width/6)));}public int method_1727(String s){return s.length()*6;}}
