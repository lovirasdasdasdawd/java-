package net.minecraft;public class class_5250 implements class_2561{private final String s;public class_5250(String s){this.s=s;}public String getString(){return s;}}
