package net.minecraft;
public class class_7532 {public static void method_52722(class_332 g,class_8685 skin,int x,int y,int s){}}
