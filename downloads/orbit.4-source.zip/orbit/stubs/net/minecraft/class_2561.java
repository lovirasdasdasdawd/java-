package net.minecraft; public interface class_2561 {static class_5250 method_43470(String s){return new class_5250(s);}String getString();}
