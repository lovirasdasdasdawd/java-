package net.minecraft;public record class_11908(int comp_4795){}
