package net.minecraft;
import java.awt.*;import java.awt.image.*;import org.joml.Matrix3x2fStack;
public class class_332 {
 public final BufferedImage image;public final Matrix3x2fStack matrices=new Matrix3x2fStack(); public int calls=0,textCalls=0;
 public class_332(int w,int h){image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);}
 public void method_25294(int x,int y,int r,int b,int c){
  if(r<x||b<y)throw new AssertionError("Inverted rectangle");
  Graphics2D g=image.createGraphics();g.setTransform(matrices.transform);g.setColor(new Color(c,true));g.fillRect(x,y,r-x,b-y);g.dispose();calls++;
 }
 public void method_25296(int x,int y,int r,int b,int top,int bottom){Graphics2D g=image.createGraphics();g.setTransform(matrices.transform);g.setPaint(new GradientPaint(x,y,new Color(top,true),x,Math.max(y+1,b),new Color(bottom,true)));g.fillRect(x,y,r-x,b-y);g.dispose();calls++;}
 public int method_51421(){return image.getWidth();}public int method_51443(){return image.getHeight();}
 public Matrix3x2fStack method_51448(){return matrices;}
 public void method_51433(class_327 font,String s,int x,int y,int c,boolean shadow){Graphics2D g=image.createGraphics();g.setTransform(matrices.transform);g.setColor(new Color(c,true));g.setFont(new Font(Font.MONOSPACED,Font.PLAIN,10));g.drawString(s,x,y+8);g.dispose();textCalls++;}
}
