package net.minecraft;
public class class_310 {
 private static final class_310 INSTANCE=new class_310();
 public class_327 field_1772=new class_327();
 public static class_310 method_1551(){return INSTANCE;}
 public class_437 current;public void method_1507(class_437 screen){current=screen;}
 public class_634 method_1562(){return null;}
}
