package org.joml;
public class Matrix3x2fStack extends Matrix3x2f {
 private final java.util.Deque<java.awt.geom.AffineTransform> stack=new java.util.ArrayDeque<>();
 public Matrix3x2fStack pushMatrix(){stack.push(new java.awt.geom.AffineTransform(transform));return this;}
 public Matrix3x2fStack popMatrix(){transform=stack.pop();return this;}
 public int depth(){return stack.size();}
}
