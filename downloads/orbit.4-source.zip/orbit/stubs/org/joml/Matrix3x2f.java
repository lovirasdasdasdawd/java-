package org.joml;
public class Matrix3x2f {
 public java.awt.geom.AffineTransform transform=new java.awt.geom.AffineTransform();
 public Matrix3x2f translate(float x,float y){transform.translate(x,y);return this;}
 public Matrix3x2f scale(float x,float y){transform.scale(x,y);return this;}
}
