package dev.donuttracker.core;
public class CapeComposition {
 public static int fieldwork$sample(CapePattern.Design d,double x,double y,int a,int c,CapeTuning t){return 0;}
 public static int fieldwork$cloth(CapePattern.Design d,double x,double y,int b,int a){return 0;}
}
