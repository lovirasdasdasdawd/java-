package dev.donuttracker.fabric;
import net.minecraft.*;
class CapesScreen extends class_437 {
 CapesScreen(DonutTrackerClient m,class_437 p){super(class_2561.method_43470(""));}
 CapesScreen(DonutTrackerClient m,class_437 p,boolean payment){this(m,p);}
}
