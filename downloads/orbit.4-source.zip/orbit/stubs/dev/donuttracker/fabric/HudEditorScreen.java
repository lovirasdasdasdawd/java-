package dev.donuttracker.fabric;
import net.minecraft.*;
class HudEditorScreen extends class_437 {
 HudEditorScreen(DonutTrackerClient m,class_437 p){super(class_2561.method_43470(""));}
 HudEditorScreen(DonutTrackerClient m,class_437 p,boolean payment){this(m,p);}
}
