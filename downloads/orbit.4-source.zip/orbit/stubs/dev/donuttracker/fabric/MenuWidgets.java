package dev.donuttracker.fabric;
import java.util.function.*;import net.minecraft.*;
final class MenuWidgets {
 enum Kind{SECONDARY,PRIMARY,TAB,CHOICE,NAV;}
 static void text(class_332 g,String s,int x,int y,int c){g.method_51433(class_310.method_1551().field_1772,s,x,y,c,false);}
 static class Action extends class_339 {
  final IntSupplier accent;final BooleanSupplier selected;final Kind kind;final int illustration;public final Runnable run;
  Action(int x,int y,int w,int h,String label,IntSupplier a,Kind k,Runnable run){this(x,y,w,h,label,a,k,()->false,-1,run);}
  Action(int x,int y,int w,int h,String label,IntSupplier a,Kind k,BooleanSupplier s,int i,Runnable run){this.x=x;this.y=y;this.w=w;this.h=h;this.label=class_2561.method_43470(label);accent=a;kind=k;selected=s;illustration=i;this.run=run;}
 }
}
