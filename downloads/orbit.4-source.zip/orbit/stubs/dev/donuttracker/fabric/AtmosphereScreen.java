package dev.donuttracker.fabric;
import net.minecraft.*;
class AtmosphereScreen extends class_437 {
 AtmosphereScreen(DonutTrackerClient m,class_437 p){super(class_2561.method_43470(""));}
 AtmosphereScreen(DonutTrackerClient m,class_437 p,boolean payment){this(m,p);}
}
