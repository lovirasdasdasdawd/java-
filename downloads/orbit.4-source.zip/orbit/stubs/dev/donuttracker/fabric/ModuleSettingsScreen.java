package dev.donuttracker.fabric;
import net.minecraft.*;
class ModuleSettingsScreen extends class_437 {
 ModuleSettingsScreen(DonutTrackerClient m,class_437 p){super(class_2561.method_43470(""));}
 ModuleSettingsScreen(DonutTrackerClient m,class_437 p,boolean payment){this(m,p);}
}
