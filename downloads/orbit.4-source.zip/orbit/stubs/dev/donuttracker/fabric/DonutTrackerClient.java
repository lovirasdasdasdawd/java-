package dev.donuttracker.fabric;
import dev.donuttracker.core.*;import dev.auctionmod.AuctionModClient;
public class DonutTrackerClient {public Settings settings=new Settings();public Tracker tracker=new Tracker();public PaymentQueue queue=new PaymentQueue();public AuctionModClient auctions=new AuctionModClient();public void save(){}public int sessionCommand(boolean start){if(start)tracker.startPayments();else tracker.stop();return 1;}}
