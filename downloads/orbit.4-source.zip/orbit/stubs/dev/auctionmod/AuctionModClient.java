package dev.auctionmod;public class AuctionModClient {public void openScreen(net.minecraft.class_437 parent){}}
