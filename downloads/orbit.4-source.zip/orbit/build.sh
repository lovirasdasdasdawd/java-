#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
original_jar="$(realpath -- "${1:?Usage: ./build.sh /path/to/original-mod.jar}")"
python3 - "$original_jar" <<'PY'
import sys,pathlib,hashlib,json,urllib.request
original=pathlib.Path(sys.argv[1])
assert hashlib.sha256(original.read_bytes()).hexdigest()==pathlib.Path('original.sha256').read_text().strip(), 'This patch targets the exact uploaded 1.21.0 JAR only'
pathlib.Path('tools').mkdir(exist_ok=True)
for name,digest in json.loads(pathlib.Path('tools.lock.json').read_text()).items():
 p=pathlib.Path('tools')/(name+'.jar')
 if not p.exists():p.write_bytes(urllib.request.urlopen(f'https://repo.maven.apache.org/maven2/org/ow2/asm/{name}/9.7.1/{name}-9.7.1.jar').read())
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest, 'Tool checksum mismatch: '+name
PY
mkdir -p build/classes build/test-classes dist
mapfile -t compile_stubs < <(find stubs -name '*.java' -print | sort)
java Compile.java -source 21 -target 21 -cp "$original_jar" -d build/stub-classes "${compile_stubs[@]}"
mapfile -t sources < <(find src -name '*.java' -print | sort)
java Compile.java -source 21 -target 21 -cp "build/stub-classes:$original_jar" -d build/classes "${sources[@]}"
output_jar=dist/donut-tracker-fabric-1.21.11-1.21.0-orbit.4.jar
java -cp 'tools/*' InterfaceAudit.java "$original_jar" build/classes
java -cp 'tools/*' Patch.java "$original_jar" "$output_jar" build/classes assets
java -cp 'tools/*' RootEntryAudit.java "$output_jar"
mapfile -t test_stubs < <(find tests/stubs -name '*.java' -print | sort)
java Compile.java -source 21 -target 21 -cp "$output_jar" -d build/test-classes "${test_stubs[@]}" tests/VisualChecks.java tests/CrashRegression.java tests/MotionChecks.java tests/FloatChecks.java tests/SmoothChecks.java tests/RenderBudget.java
java -Xverify:all -Djava.awt.headless=true -cp "build/test-classes:$output_jar" dev.donuttracker.fabric.VisualChecks dist/assets
java -Xverify:all -cp "build/test-classes:$output_jar" dev.donuttracker.fabric.CrashRegression
java -Xverify:all -cp "build/test-classes:$output_jar" dev.donuttracker.fabric.MotionChecks
java -Xverify:all -Djava.awt.headless=true -cp "build/test-classes:$output_jar" dev.donuttracker.fabric.FloatChecks
java -Xverify:all -Djava.awt.headless=true -cp "build/test-classes:$output_jar" dev.donuttracker.fabric.SmoothChecks
java tests/SeasonalChecks.java "$original_jar" "$output_jar"
python3 verify_release.py "$original_jar" "$output_jar"
