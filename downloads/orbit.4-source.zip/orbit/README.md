# ORBIT / Donut Tracker 1.21.0

A curved/radial alternative to the Fieldwork visual edition, based on the uploaded Donut Tracker 1.21.0 JAR for Minecraft 1.21.11. The original author metadata is retained. This build preserves the Fieldwork.2 Minecraft Text-interface crash fix.

## Install

Replace your prior Donut Tracker / Fieldwork JAR with `donut-tracker-fabric-1.21.11-1.21.0-orbit.4.jar`. Keep exactly one `donuttracker` mod installed. Requires Java 21+, Minecraft 1.21.11, Fabric Loader 0.18.4+ and Fabric API.

Open with Right Shift. Six pill-shaped module controls orbit the session readout: Tracker, Payments, Auctions, Capes, Style and HUDs. Start/end-session and Close remain separate controls. Existing command, tracking and configuration logic is retained.

The default palette is **Orbit**: graphite, warm apricot accents and sage profit values. Existing configuration is preserved. To switch from a different saved palette, use `Style → Interface palette: Orbit`. The default Aurora atmosphere now uses a quiet dark backdrop with curved perimeter marks; other saved atmospheres remain selectable.

## Shape changes

- Circular navigation layout with a donut-shaped session readout, moving status arc while recording, and floating telemetry instead of overview cards.
- Session and payment HUDs use a circular icon badge joined to a long capsule, with detached rounded timer/queue strips. Layouts remain minimal, compact and stacked.
- Curved action controls with hover, selected, disabled and focus styles; the existing callbacks and rectangular widget hit regions are retained.
- Existing submenus retain their content layout inside rounded panels. Their tracker/payment/auction functionality is unchanged.
- Fourteen cape designs and the Fieldwork compass/antler native item-model resources are retained. The three winter capes remain pixel-identical to the uploaded mod. This update does not add a new automatic wearable-cosmetic system.

## Checks

- InterfaceAudit verifies Minecraft invocation interface flags against the uploaded original.
- The dashboard-construction regression for the previously reported `InterfaceMethodref` crash passes.
- ASM bytecode checks and JVM verification pass.
- 54 HUD states and five menu sizes render through an offscreen adapter; button hit regions stay within the screen and do not overlap. Session start/stop, navigation and Right Shift closure are exercised.
- All 14 cape designs generate; the three seasonal designs preserve cloth, glow and preview pixels.
- JAR integrity, native model/texture references and preservation of tracker/queue/auction logic and existing mixins pass.

**Minecraft itself was not launched.** The previews use the actual drawing code with test Minecraft interfaces and a substitute font. They are offscreen renders, not game screenshots. Actual input handling, GPU appearance and interaction with other mods still need an in-game playtest.

## Rebuild

Requires Java 21 with `jdk.compiler`, Python 3 and Maven Central access for four checksum-pinned ASM tools:

```bash
./build.sh /path/to/donut-tracker-fabric-1.21.11-1.21.0.jar
```

The input is pinned by `original.sha256`. New runtime source is in `src`; `Patch.java` edits specific original rendering methods. `stubs` and `tests/stubs` are compile/test-only interfaces and are excluded from the runtime JAR. The original JAR is required and is not included in the source archive.

## Orbit.2 opening/closing animation

Only the original Right Shift entry creates an animated root menu. It grows from 4% to 100% over 280 ms around the screen center. Right Shift, Close and Escape shrink it to zero over 180 ms; the parent screen is restored after the animation completes. Early closes reverse from the current scale and repeated closes do not reset the timer.

All menu content and controls share the transform. Input is blocked while transitioning. The backdrop and in-game HUD are not part of the scale animation. Module navigation, returning from modules, layout changes and session start/stop do not restart the opening animation.

RootEntryAudit checks the hotkey constructor flag in the built JAR. MotionChecks passes 100 deterministic assertions, covering both easing directions, early/repeated closes, centered scaling, control transforms, input blocking, parent restoration, and immediate module navigation. The other offscreen, interface-crash, archive and seasonal checks also pass. Minecraft itself remains unlaunched here.

## Orbit.3 gentle module float

The six buttons surrounding the center bubble now float around immutable layout anchors: up to 1.5 pixels horizontally and 2 pixels vertically at full UI scale, with different phases and slow 6.4/4.8-second rhythms. Drawing uses fractional-pixel translation, while Minecraft widget positions follow the nearest pixel so hit regions follow the visible controls. Hover and keyboard focus hold a button steady; release eases back into the motion. Closing freezes the current float offset. Start/end-session, Close and the HUD do not float.

Orbit.2's 280 ms Right Shift grow-in and 180 ms shrink-out behavior is retained. Module navigation and returning to the overview do not restart the scale animation. The Minecraft Text-interface crash fix is retained.

FloatChecks passes 39,901 deterministic assertions for bounded motion, draw/hitbox consistency, hover/focus hold, smooth resume, stable nonmodule controls, five viewport sizes and balanced render transforms. MotionChecks and the existing interface/crash/visual/seasonal/archive suites also pass. Position setters were checked against official Yarn 1.21.11+build.6 mappings. Minecraft itself was not launched.

## Orbit.4 smoother motion and lighter rendering

- Floating buttons now use critically damped motion with velocity continuity, slower 8.8/6.8-second rhythms, and subpixel drawing. Hover coasts to rest within a fraction of a pixel instead of instantly cancelling movement; release resumes without a position jump. Motion remains bounded to 1.5 by 2 pixels at full scale.
- Hover borders/backgrounds fade over time instead of changing immediately. During menu scaling, controls remain visually enabled while actual input stays blocked, avoiding a disabled-colour flash when opening finishes.
- Opening/closing now use minimum-jerk quintic easing with zero endpoint velocity/acceleration: **400 ms grow-in**, **260 ms shrink-out**. The Right Shift-only entry, repeated-close protection, and immediate module navigation remain intact.
- Capsule and ring geometry is cached and vertically merged. Large backdrop arc geometry is cached and drawn without overlapping alpha fills. In the offscreen 560×320 menu benchmark, fill calls fell from **3,193 (Orbit.3)** to **1,995 (Orbit.4)**, about **38% fewer commands**. This is a drawing-command comparison, not an in-game FPS measurement.

SmoothChecks passes 406 assertions covering closely matching float paths at simulated 30/60/144 FPS, hover velocity continuity, settling/release, hover colour fades, easing endpoints and pixel-identical merged capsule fills. The other motion, floating, interface-crash, visual, seasonal and archive suites pass. Minecraft itself was not launched.
