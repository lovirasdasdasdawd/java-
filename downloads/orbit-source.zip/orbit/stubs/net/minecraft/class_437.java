package net.minecraft;
public class class_437 implements class_364 {
 public int field_22789=560,field_22790=320;public class_310 field_22787=class_310.method_1551();public class_327 field_22793=field_22787.field_1772;
 public final java.util.List<class_364> children=new java.util.ArrayList<>();
 public class_437(class_2561 title){}protected void method_25426(){}public void method_25394(class_332 g,int x,int y,float d){}public boolean method_25404(class_11908 e){return false;}public void method_25419(){}public boolean method_25421(){return false;}
 protected <T extends class_364>T method_37063(T child){children.add(child);return child;}protected void method_41843(){children.clear();method_25426();}
}
