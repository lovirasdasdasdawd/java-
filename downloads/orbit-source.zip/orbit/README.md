# ORBIT / Donut Tracker 1.21.0

A curved/radial alternative to the Fieldwork visual edition, based on the uploaded Donut Tracker 1.21.0 JAR for Minecraft 1.21.11. The original author metadata is retained. This build preserves the Fieldwork.2 Minecraft Text-interface crash fix.

## Install

Replace your prior Donut Tracker / Fieldwork JAR with `donut-tracker-fabric-1.21.11-1.21.0-orbit.1.jar`. Keep exactly one `donuttracker` mod installed. Requires Java 21+, Minecraft 1.21.11, Fabric Loader 0.18.4+ and Fabric API.

Open with Right Shift. Six pill-shaped module controls orbit the session readout: Tracker, Payments, Auctions, Capes, Style and HUDs. Start/end-session and Close remain separate controls. Existing command, tracking and configuration logic is retained.

The default palette is **Orbit**: graphite, warm apricot accents and sage profit values. Existing configuration is preserved. To switch from a different saved palette, use `Style → Interface palette: Orbit`. The default Aurora atmosphere now uses a quiet dark backdrop with curved perimeter marks; other saved atmospheres remain selectable.

## Shape changes

- Circular navigation layout with a donut-shaped session readout, moving status arc while recording, and floating telemetry instead of overview cards.
- Session and payment HUDs use a circular icon badge joined to a long capsule, with detached rounded timer/queue strips. Layouts remain minimal, compact and stacked.
- Curved action controls with hover, selected, disabled and focus styles; the existing callbacks and rectangular widget hit regions are retained.
- Existing submenus retain their content layout inside rounded panels. Their tracker/payment/auction functionality is unchanged.
- Fourteen cape designs and the Fieldwork compass/antler native item-model resources are retained. The three winter capes remain pixel-identical to the uploaded mod. This update does not add a new automatic wearable-cosmetic system.

## Checks

- InterfaceAudit verifies Minecraft invocation interface flags against the uploaded original.
- The dashboard-construction regression for the previously reported `InterfaceMethodref` crash passes.
- ASM bytecode checks and JVM verification pass.
- 54 HUD states and five menu sizes render through an offscreen adapter; button hit regions stay within the screen and do not overlap. Session start/stop, navigation and Right Shift closure are exercised.
- All 14 cape designs generate; the three seasonal designs preserve cloth, glow and preview pixels.
- JAR integrity, native model/texture references and preservation of tracker/queue/auction logic and existing mixins pass.

**Minecraft itself was not launched.** The previews use the actual drawing code with test Minecraft interfaces and a substitute font. They are offscreen renders, not game screenshots. Actual input handling, GPU appearance and interaction with other mods still need an in-game playtest.

## Rebuild

Requires Java 21 with `jdk.compiler`, Python 3 and Maven Central access for four checksum-pinned ASM tools:

```bash
./build.sh /path/to/donut-tracker-fabric-1.21.11-1.21.0.jar
```

The input is pinned by `original.sha256`. New runtime source is in `src`; `Patch.java` edits specific original rendering methods. `stubs` and `tests/stubs` are compile/test-only interfaces and are excluded from the runtime JAR. The original JAR is required and is not included in the source archive.
