import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 static String V="dev/donuttracker/fabric/AtelierVisuals", C="Lnet/minecraft/class_332;";
 static int changed=0;
 static void integer(InsnList l,int n){l.add(new LdcInsnNode(n));}
 static void load(InsnList l,int... slots){for(int i:slots)l.add(new VarInsnNode(i==0?ALOAD:ILOAD,i));}
 static void call(InsnList l,String owner,String name,String desc){l.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));}
 static void body(MethodNode m,InsnList l){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;m.instructions.add(l);m.maxStack=32;m.maxLocals=Math.max(m.maxLocals,20);changed++;}
 static Integer number(AbstractInsnNode n){if(n instanceof LdcInsnNode c&&c.cst instanceof Integer i)return i;if(n instanceof IntInsnNode i)return i.operand;if(n.getOpcode()>=ICONST_M1&&n.getOpcode()<=ICONST_5)return n.getOpcode()-ICONST_0;return null;}
 static void replaceInt(MethodNode m,Map<Integer,Integer> values){for(AbstractInsnNode n:m.instructions.toArray()){Integer old=number(n);if(old!=null&&values.containsKey(old)){m.instructions.set(n,new LdcInsnNode(values.get(old)));changed++;}}}
 static byte[] transform(String path,byte[] bytes)throws Exception {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int before=changed;
  List<MethodNode> additions=new ArrayList<>();
  for(MethodNode m:c.methods){
   String name=c.name;
   if(name.equals("dev/donuttracker/fabric/CoastalStyle")){
    Map<String,int[]> colors=Map.of("panel",new int[]{-15721936,0xff161b23},"surface",new int[]{-15325888,0xff202834},"line",new int[]{-12560779,0xff354252},"ink",new int[]{-1643016,0xfff0e9df},"muted",new int[]{-5851698,0xff99a7b8},"accent",new int[]{-6493230,0xffedab7a});
    if(m.name.equals("matchHud"))replaceInt(m,Map.of(10871735,0xacd5a6,16032406,0xe58a85));
    if(m.name.equals("primaryInk"))replaceInt(m,Map.of(-15189442,0xff18212b));
    if(m.name.equals("value")||m.name.equals("controlAccent")){
     InsnList l=new InsnList();if(m.name.equals("value")){l.add(new VarInsnNode(ILOAD,0));l.add(new VarInsnNode(ILOAD,1));}else l.add(new VarInsnNode(ILOAD,0));
     l.add(new FieldInsnNode(GETSTATIC,name,"palette","Ldev/donuttracker/core/Settings$MenuPalette;"));call(l,V,m.name,m.name.equals("value")?"(ZILdev/donuttracker/core/Settings$MenuPalette;)I":"(ILdev/donuttracker/core/Settings$MenuPalette;)I");l.add(new InsnNode(IRETURN));body(m,l);
    }
    if(colors.containsKey(m.name)){int[] co=colors.get(m.name);replaceInt(m,Map.of(co[0],co[1]));}
    if(m.name.equals("paletteName"))for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof LdcInsnNode l&&l.cst.equals("Aurora")){l.cst="Orbit";changed++;}
    if((m.name.equals("panel")||m.name.equals("glass"))&&m.desc.equals("("+C+"IIII)V")){
     InsnList l=new InsnList();load(l,0,1,2,3,4);
     for(String s:new String[]{"panel","line","accent"})call(l,name,s,"()I");
     if(m.name.equals("panel")){
      l.add(new FieldInsnNode(GETSTATIC,name,"glassOpacity","F"));l.add(new LdcInsnNode(255f));l.add(new InsnNode(FMUL));l.add(new InsnNode(F2I));
      // Opaque mode keeps its original behavior; choose alpha through a helper-free boolean blend.
      l.add(new FieldInsnNode(GETSTATIC,name,"glass","Z"));l.add(new InsnNode(IMUL));
      integer(l,255);l.add(new FieldInsnNode(GETSTATIC,name,"glass","Z"));integer(l,255);l.add(new InsnNode(IMUL));l.add(new InsnNode(ISUB));l.add(new InsnNode(IADD));
     }else integer(l,235);
     call(l,V,"panel","("+C+"IIIIIIII)V");l.add(new InsnNode(RETURN));body(m,l);
    }
   }
   if(name.equals("dev/donuttracker/fabric/TrackerHud")){
    if(m.name.equals("width")){InsnList l=new InsnList();integer(l,220);l.add(new InsnNode(IRETURN));body(m,l);}
    if(m.name.equals("height")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));call(l,"dev/donuttracker/fabric/FieldworkHud","height",m.desc);l.add(new InsnNode(IRETURN));body(m,l);}
    if(m.name.equals("draw")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(new VarInsnNode(ILOAD,3));l.add(new VarInsnNode(ILOAD,4));call(l,"dev/donuttracker/fabric/FieldworkHud","draw",m.desc);l.add(new InsnNode(RETURN));body(m,l);}

    if(Set.of("donut","people","clock").contains(m.name)){
     InsnList l=new InsnList();load(l,0,1,2,3);call(l,V,m.name,m.desc);l.add(new InsnNode(RETURN));body(m,l);
    }
    if((m.name.equals("rounded")||m.name.equals("border"))&&m.desc.equals("("+C+"IIIIII)V")){
     InsnList l=new InsnList();load(l,0,1,2,3,4,5,6);call(l,V,m.name,m.desc);l.add(new InsnNode(RETURN));body(m,l);
    }
   }
   if(name.equals("dev/donuttracker/fabric/AuroraBackdrop")&&m.name.equals("draw")&&m.desc.contains("Settings$SceneDesign")){
    InsnList l=new InsnList();load(l,0,1,2,3,4,5);l.add(new VarInsnNode(FLOAD,6));
    for(String field:new String[]{"tint","speed","density"}){l.add(new VarInsnNode(ALOAD,7));l.add(new FieldInsnNode(GETFIELD,"dev/donuttracker/core/Settings$SceneDesign",field,field.equals("tint")?"I":"D"));}
    call(l,V,"backdrop","("+C+"IIIIZFIDD)V");l.add(new InsnNode(RETURN));body(m,l);
   }

   if(name.equals("dev/donuttracker/fabric/MenuWidgets$Action")&&m.name.equals("method_75752")){
    InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ILOAD,2));l.add(new VarInsnNode(ILOAD,3));l.add(new VarInsnNode(FLOAD,4));call(l,"dev/donuttracker/fabric/FieldworkWidgets","draw","(Ldev/donuttracker/fabric/MenuWidgets$Action;"+C+"IIF)V");l.add(new InsnNode(RETURN));body(m,l);
   }
   if(name.startsWith("dev/auctionmod/")&&Set.of("AuctionUi","AuctionUi$Action","AuctionUi$ScaleSlider","AuctionHud","AuctionScreen","AuctionHudEditor").contains(name.substring(name.lastIndexOf('/')+1))){
    replaceInt(m,Map.of(-9511443,0xffedab7a,-1183243,0xfff0e9df,-6248267,0xff99a7b8,-993683,0xffacd5a6,-13351851,0xff354252,-14404794,0xff202834,-12102038,0xff354252));
    if(name.equals("dev/auctionmod/AuctionHud"))for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof LdcInsnNode l&&l.cst.equals("Auction Mod by claude")){l.cst="AUCTION HOUSE";changed++;}
   }
   if(name.equals("dev/auctionmod/AuctionUi")&&m.name.equals("round")){
    InsnList l=new InsnList();load(l,0,1,2);l.add(new VarInsnNode(ILOAD,1));l.add(new VarInsnNode(ILOAD,3));l.add(new InsnNode(IADD));l.add(new VarInsnNode(ILOAD,2));l.add(new VarInsnNode(ILOAD,4));l.add(new InsnNode(IADD));l.add(new VarInsnNode(ILOAD,5));integer(l,3);call(l,V,"rounded","("+C+"IIIIII)V");l.add(new InsnNode(RETURN));body(m,l);
   }
   if(name.equals("dev/auctionmod/AuctionUi")&&m.name.equals("panel")){
    InsnList l=new InsnList();load(l,0,1,2,3,4);integer(l,0xff161b23);integer(l,0xff354252);integer(l,0xffedab7a);integer(l,255);l.add(new VarInsnNode(ILOAD,5));integer(l,30);l.add(new InsnNode(IMUL));l.add(new InsnNode(ISUB));call(l,V,"panel","("+C+"IIIIIIII)V");l.add(new InsnNode(RETURN));body(m,l);
   }
   if(name.equals("dev/donuttracker/core/Settings$Hud")&&m.name.equals("<init>"))replaceInt(m,Map.of(9492418,0xd9754e,15984843,0xeee8dd,10871735,0xa9c48a,16032406,0xe58a85,862003,0x202723));
   if(name.equals("dev/donuttracker/core/Settings")&&m.name.equals("<init>"))replaceInt(m,Map.of(11978473,0x86b9c3));
   if(name.equals("dev/donuttracker/core/CapeComposition")&&Set.of("sample","cloth").contains(m.name)){
    String originalName=m.name;m.name="fieldwork$"+originalName;MethodNode wrapper=new MethodNode(ACC_PUBLIC|ACC_STATIC,originalName,m.desc,null,null);
    InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(DLOAD,1));l.add(new VarInsnNode(DLOAD,3));l.add(new VarInsnNode(ILOAD,5));l.add(new VarInsnNode(ILOAD,6));if(originalName.equals("sample"))l.add(new VarInsnNode(ALOAD,7));call(l,"dev/donuttracker/core/AtelierEmblems",originalName,m.desc);l.add(new InsnNode(IRETURN));body(wrapper,l);additions.add(wrapper);
   }
   if(name.equals("dev/donuttracker/core/CapeStudio")&&m.name.equals("create")&&m.desc.contains("CapeTuning")){
    InsnList prefix=new InsnList();prefix.add(new InsnNode(ACONST_NULL));prefix.add(new VarInsnNode(ASTORE,9));m.instructions.insert(prefix);changed++;
   }
  }
  c.methods.addAll(additions);
  if(changed==before)return bytes;
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] output=w.toByteArray();
  ClassNode check=new ClassNode();new ClassReader(output).accept(check,0);
  for(MethodNode m:check.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(check.name,m);
  System.out.println("Patched and bytecode-checked: "+path);return output;
 }
 public static void main(String[] args)throws Exception{
  try(ZipFile input=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
   for(ZipEntry e:Collections.list(input.entries())){
    if(e.isDirectory())continue; if(e.getName().equals("dev/donuttracker/fabric/TrackerScreen.class"))continue;byte[] b=input.getInputStream(e).readAllBytes();
    if(e.getName().endsWith(".class"))b=transform(e.getName(),b);
    if(e.getName().equals("fabric.mod.json")){String s=new String(b,java.nio.charset.StandardCharsets.UTF_8).replace("\"version\": \"1.21.0\"","\"version\": \"1.21.0+orbit.1\"").replace("\"name\": \"Donut Tracker + Auctions\"","\"name\": \"Donut Tracker + Auctions — Orbit\"");b=s.getBytes(java.nio.charset.StandardCharsets.UTF_8);}
    ZipEntry next=new ZipEntry(e.getName());next.setTime(0);out.putNextEntry(next);out.write(b);out.closeEntry();
   }
   Path root=Path.of(args[2]);try(var files=Files.walk(root)){for(Path p:files.filter(Files::isRegularFile).sorted().toList()){
    String n=root.relativize(p).toString();if(!n.startsWith("dev/"))continue;
    byte[] code=Files.readAllBytes(p);ClassNode generated=new ClassNode();new ClassReader(code).accept(generated,0);
    for(MethodNode method:generated.methods)if((method.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(generated.name,method);
    ZipEntry e=new ZipEntry(n);e.setTime(0);out.putNextEntry(e);out.write(code);out.closeEntry();
   }}
   if(args.length>3){Path assets=Path.of(args[3]);try(var files=Files.walk(assets)){for(Path p:files.filter(Files::isRegularFile).sorted().toList()){
    ZipEntry entry=new ZipEntry("assets/"+assets.relativize(p).toString());entry.setTime(0);out.putNextEntry(entry);out.write(Files.readAllBytes(p));out.closeEntry();
   }}}
  }
  if(changed<20)throw new IllegalStateException("Unexpected patch count: "+changed);
  System.out.println("Visual edits: "+changed);
 }
}
